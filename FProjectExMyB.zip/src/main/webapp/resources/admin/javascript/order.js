function go_search() {
	var theForm = document.frm;
	theForm.action =  "admin_order_list";
	theForm.submit();
}
