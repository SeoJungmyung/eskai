package com.spring.flower.dto;

public class NoticeVO {
	
	private int notiNum;
	private String id;
	private String noti_title;
	private String noti_contents;
	private String noti_date;
	private String noti_true;
	
	public int getNotiNum() {
		return notiNum;
	}
	public void setNotiNum(int notiNum) {
		this.notiNum = notiNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNoti_title() {
		return noti_title;
	}
	public void setNoti_title(String noti_title) {
		this.noti_title = noti_title;
	}
	public String getNoti_contents() {
		return noti_contents;
	}
	public void setNoti_contents(String noti_contents) {
		this.noti_contents = noti_contents;
	}
	public String getNoti_date() {
		return noti_date;
	}
	public void setNoti_date(String noti_date) {
		this.noti_date = noti_date;
	}
	public String getNoti_true() {
		return noti_true;
	}
	public void setNoti_true(String noti_true) {
		this.noti_true = noti_true;
	}
	
	
}
