package com.spring.flower.dto;

public class ReviewVO {
	private int rev_num;
	private String rev_pass;
	private String rev_title;
	private String rev_contents;
	private String rev_date;
	private String rev_update;
	private int rev_click;
	private String rev_rev;
	private int rev_score;
	private String rev_pic;
	private String orderNum;
	private String id;
	private String p_pic;
	
	public String getP_pic() {
		return p_pic;
	}
	public void setP_pic(String p_pic) {
		this.p_pic = p_pic;
	}
	public int getRev_num() {
		return rev_num;
	}
	public void setRev_num(int rev_num) {
		this.rev_num = rev_num;
	}
	public String getRev_pass() {
		return rev_pass;
	}
	public void setRev_pass(String rev_pass) {
		this.rev_pass = rev_pass;
	}
	public String getRev_title() {
		return rev_title;
	}
	public void setRev_title(String rev_title) {
		this.rev_title = rev_title;
	}
	public String getRev_contents() {
		return rev_contents;
	}
	public void setRev_contents(String rev_contents) {
		this.rev_contents = rev_contents;
	}
	public String getRev_date() {
		return rev_date;
	}
	public void setRev_date(String rev_date) {
		this.rev_date = rev_date;
	}
	public String getRev_update() {
		return rev_update;
	}
	public void setRev_update(String rev_update) {
		this.rev_update = rev_update;
	}
	public int getRev_click() {
		return rev_click;
	}
	public void setRev_click(int rev_click) {
		this.rev_click = rev_click;
	}
	public String getRev_rev() {
		return rev_rev;
	}
	public void setRev_rev(String rev_rev) {
		this.rev_rev = rev_rev;
	}
	public int getRev_score() {
		return rev_score;
	}
	public void setRev_score(int rev_score) {
		this.rev_score = rev_score;
	}
	public String getRev_pic() {
		return rev_pic;
	}
	public void setRev_pic(String rev_pic) {
		this.rev_pic = rev_pic;
	}
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
}
